using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

# Write to the Azure Functions log stream.
Write-Host "PowerShell HTTP trigger function processed a request."

#Getting parameters from the request
$securityGroupID = $Request.Body.securityGroupID
$microsoftGroupID = $Request.Body.microsoftGroupID
$siteUrl = $Request.Body.siteUrl

#Settings to connect to SharePoint and Azure AD, will be loaded from a secure place later
$appId = $env:AzureAppId
$thumbprint = $env:WEBSITE_LOAD_CERTIFICATES
$tenantId =  $env:TenantId
$currentDate = Get-Date -Format 'dd/MM/yyyy'
$currentHours = Get-Date -Format 'HH'
$currentMinutes= Get-Date -Format 'mm'
$syncDate =  $currentDate + " at " +  $currentHours+"h"+$currentMinutes

try{
    #Connect to SharePoint and Azure AD, SharePoint first 

    $spconnect = Connect-PnPOnline -ClientId $appId -Thumbprint $thumbprint -Tenant $tenantId -Url $siteUrl
    $azconnect = Connect-AzAccount -CertificateThumbprint $thumbprint -ApplicationId $appId -Tenant $tenantId -ServicePrincipal


    #Get item from SharePoint, and field SecurityGroupUsers ; MicrosoftGroupUsers
    $listSecurityMembersJson = Get-PnPPropertyBag -Key "SecurityGroupUsers"
    $global:listSecurityMembers = $listSecurityMembersJson | ConvertFrom-Json
    $global:listSecurityMembersId = @()
    foreach($member in $global:listSecurityMembers){
        $global:listSecurityMembersId += $member.Id
    }
    $listMicrosoftMembersJson = Get-PnPPropertyBag -Key "MicrosoftGroupUsers"
    $global:listMicrosoftMembers = $listMicrosoftMembersJson | ConvertFrom-Json
    $global:listMicrosoftMembersId = @()
    foreach($member in $global:listMicrosoftMembers){
        $global:listMicrosoftMembersId += $member.Id
    }
    $global:addedMembers = @()
    $global:removedMembers = @()
    $global:newListSecurityMembers = @()
    #Instance 2 array for security users
    $global:securityGroupMembers = @()
    $global:securitGroupMembersId = @()

    #function to get security group members
    function getSecurityGroupMembers {
        param([Parameter(Mandatory = $true)] [string] $securityGroupID)
        Write-Host "Entering get security group members"
        $securityGroup = Get-AzADGroupMember -GroupObjectId $securityGroupID
        #foreach members, add it to arrays if user, if group call function again
        foreach($member in $securityGroup){
            if($member.Type -eq "User"){
                $global:securityGroupMembers += $member
                $global:securitGroupMembersId += $member.Id
            }
            elseIf($member.Type -eq "Group"){
                getSecurityGroupMembers -securityGroupID $member.Id 
            }
        }
    }
    #Call function
    getSecurityGroupMembers -securityGroupID $securityGroupId
    Write-Host $global:securityGroupMembers

    #function to add new security members to microsoft group
    function AddMembers {
    param([Parameter(Mandatory = $true)] [string] $microsoftGroupID)
        Write-Host "Entering Function"
        #foreach member of security group, add it to group if not already in
        foreach($member in $global:securityGroupMembers){   
            if((-Not($global:listSecurityMembersId -contains $member.Id))  -and (-Not($global:listMicrosoftMembersId -contains $member.Id))){
                Add-AzADGroupMember -MemberObjectId $member.Id -TargetGroupObjectId $microsoftGroupID    
                $global:addedMembers += $member.DisplayName 
            }  
            else {
                Write-Host "Already exist"
            }  
            $global:newListSecurityMembers += @{Id = $member.Id ; Name = $member.DisplayName}  
        }
    }
    #call function
    AddMembers -microsoftGroupID $microsoftGroupID
    #function to remove members that are no more in security group and not in microsoft group
    function RemoveMembers{
        param([Parameter(Mandatory = $true)] [string] $microsoftGroupID)

        foreach($member in $global:listSecurityMembers){
            if( (-Not($global:securitGroupMembersId -contains $member.Id)) -and (-Not($global:listMicrosoftMembersId -contains $member.Id)) ){
                Remove-AzADGroupMember -GroupObjectId $microsoftGroupID -MemberObjectId $member.Id
                $global:removedMembers += $member.Name
                Write-Host $member.Name "removed"
            }
            else{
                Write-Host "Users is in security Group"
            }
        }    
    }
    #call function
    RemoveMembers -microsoftGroupID $microsoftGroupID
    #Set SharePoint item to refresh SecurityGroupUsers field
    $listSecurityMembersJson = $global:newListSecurityMembers |ConvertTo-Json
    Set-PnPPropertyBagValue -Key "SecurityGroupUsers" -Value $listSecurityMembersJson
    Set-PnPPropertyBagValue -Key "LastSync" -Value $syncDate
    Write-Host $global:addedMembers
    $addedMemberJson = ""
    $removedMemberJson = ""
    if($global:addedMembers.count -eq 0){
        $addedMemberJson = " "
    }
    else{
        $addedMemberJson = $global:addedMembers | ConvertTo-Json
    }
    if($global:removedMembers.count -eq 0){
        $removedMemberJson = " "
    }
    else{
        $removedMemberJson = $global:removedMembers | ConvertTo-Json
    }
  
    Write-Host $removedMemberJson
    Set-PnPPropertyBagValue -Key "AddedMember" -Value $addedMemberJson
    Set-PnPPropertyBagValue -Key "RemovedMember" -Value $removedMemberJson

    # Associate values to output bindings by calling 'Push-OutputBinding'.
    Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
        StatusCode = [HttpStatusCode]::OK
        Body = "ok"
    })
}

catch{
    Write-Host $Error
    $body = 'An error occured : ' + $Error 
    Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = [HttpStatusCode]::InternalServerError
    Body = $body
    })
}


