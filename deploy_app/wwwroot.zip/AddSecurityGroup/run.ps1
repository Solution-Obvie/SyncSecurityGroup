using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)
 
# Write to the Azure Functions log stream.
Write-Host "PowerShell HTTP trigger function processed a request."

#Getting parameters from the request
$securityGroupID = $Request.Body.securityGroupID
$microsoftGroupID = $Request.Body.microsoftGroupID
$siteUrl = $Request.Body.siteUrl
$currentUTCtime = (Get-Date).ToUniversalTime()
Write-Host $currentUTCtime

#Settings to connect to SharePoint and Azure AD, will be loaded from a secure place later
$tenantId =  $env:TenantId
$appId = $env:AzureAppId
$thumbprint = $env:WEBSITE_LOAD_CERTIFICATES


try{
    $currentDate = Get-Date -Format 'dd/MM/yyyy'
$currentHours = Get-Date -Format 'HH'
$currentMinutes= Get-Date -Format 'mm'
$syncDate =  $currentDate + " at " +  $currentHours+"h"+$currentMinutes
    #Connect to SharePoint and Azure, we must connect to SharePoint first
    $spconnect = Connect-PnPOnline -ClientId $appId -Thumbprint $thumbprint -Tenant $tenantId -Url $siteUrl
    $azconnect = Connect-AzAccount -CertificateThumbprint $thumbprint -ApplicationId $appId -Tenant $tenantId -ServicePrincipal
    #Get security group name and instance global variable users 
    $securityGroup = Get-AzADGroup -ObjectId $securityGroupID
    $securityGroupName = $securityGroup.DisplayName
    $global:securityUsersArray = @()

 $MicrosoftGroupUsersArray = @()

    #Get microsoft group users before adding security members
    $MicrosoftGroupUsers = Get-AzADGroupMember -GroupObjectId $microsoftGroupID
    foreach($member in $MicrosoftGroupUsers){
        #$MicrosoftGroupUsersArray = $MicrosoftGroupUsersArray + $member.Id + ";"
        $MicrosoftGroupUsersArray += @{Id = $member.Id ; Name = $member.DisplayName}
    }
    $MicrosoftGroupUsersArrayJson = $MicrosoftGroupUsersArray | ConvertTo-Json
    #Set microsoft users field in SharePoint list
    #$item = Set-PnPListItem -List "syncGroupAppSettings" -Identity 1 -Values @{"MicrosoftGroupUsers" = $MicrosoftGroupUsersArray}  
    Set-PnPPropertyBagValue -Key "MicrosoftGroupUsers" -Value $MicrosoftGroupUsersArrayJson

    #Function to add security users to microsoft group
    function AddMembers{
        param([Parameter(Mandatory = $true)] [string] $securityGroupID,
            [Parameter(Mandatory = $true)] [string] $microsoftGroupID)
        
            Write-Host "Entering Function"
            $securityGroupMembers = Get-AzADGroupMember -GroupObjectId $securityGroupID 
            foreach($member in $securityGroupMembers){
                if($member.Type -eq "User"){ #if the member is a user, add it to the group and variable
                    #Add member to the group
                    Add-AzADGroupMember -MemberObjectId $member.Id -TargetGroupObjectId $microsoftGroupID 
                    #Add member to variable 
                    $global:securityUsersArray += @{Id = $member.Id ; Name = $member.DisplayName} 
                }
                elseIf($member.Type -eq "Group"){ #if the member is a group, call the function again to get the members of the group recursivly
                    AddMembers -securityGroupID $member.Id -microsoftGroupID $microsoftGroupID
                }
            }
            Write-Host "Leaving Function"      
    }
    #call the function
    AddMembers -securityGroupID $securityGroupID -microsoftGroupID $microsoftGroupID
    #Set security group users in the property bag
    $securityUsersJson = $global:securityUsersArray | ConvertTo-Json
    Set-PnPPropertyBagValue -Key "SecurityGroupUsers" -Value $securityUsersJson
    #Set security group informations in the property bag
    $SecurityGroupInformations = @{Id = $securityGroupID ; Name = $securityGroupName}
    Write-Host $SecurityGroupInformations
    $SecurityGroupInformationsJson = $SecurityGroupInformations | ConvertTo-Json
       Write-Host $SecurityGroupInformationsJson
    Set-PnPPropertyBagValue -Key "SecurityGroupLinked" -Value $SecurityGroupInformationsJson
    Set-PnPPropertyBagValue -Key "LastSync" -Value $syncDate  
    #Send the reponse to SPFX app
    $body = 'ok'
    Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = [HttpStatusCode]::OK
    Body = $body
    })
}

catch {
    Write-Host $Error
    $body = 'An error occured : ' + $Error 
    Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = [HttpStatusCode]::InternalServerError
    Body = $body
    })
}






