using namespace System.Net



# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

# Write to the Azure Functions log stream.
Write-Host "PowerShell HTTP trigger function processed a request."

#Getting parameters from the request
$securityGroupID = $Request.Body.securityGroupID
$microsoftGroupID = $Request.Body.microsoftGroupID
$siteUrl = $Request.Body.siteUrl

#Settings to connect to SharePoint and Azure AD, will be loaded from a secure place later
$tenantId =  $env:TenantId
$appId = $env:AzureAppId
$thumbprint = $env:WEBSITE_LOAD_CERTIFICATES

try{
    #Connect to SharePoint and Azure, SharePoint first
    $spconnect = Connect-PnPOnline -ClientId $appId -Thumbprint $thumbprint -Tenant $tenantId -Url $siteUrl
    $azconnect = Connect-AzAccount -CertificateThumbprint $thumbprint -ApplicationId $appId -Tenant $tenantId -ServicePrincipal

    #Getting Security Group members
    $SecurityGroupUsersJson = Get-PnPPropertyBag -Key "SecurityGroupUsers"
    $global:listSecurityMembers = $SecurityGroupUsersJson | ConvertFrom-Json
    #Getting Microsoft Group members
    $MicrosoftGroupUsersJson = Get-PnPPropertyBag -Key "MicrosoftGroupUsers"
    $global:listMicrosoftMembers = $MicrosoftGroupUsersJson | ConvertFrom-Json
    Write-Host $global:listMicrosoftMembers
    $global:listMicrosoftMembersId = @()
    foreach($member in $global:listMicrosoftMembers){
        $global:listMicrosoftMembersId += $member.Id
    }

    #Foreach security group users, check if not in microsoft group too and remove if not
    foreach($member in $global:listSecurityMembers){
        if(-Not ($global:listMicrosoftMembersId -contains $member.Id))
        {
            Write-Host "Remove : " +$member.Name 
            Remove-AzADGroupMember -GroupObjectId $microsoftGroupID -MemberObjectId $member.Id
        }
    }
    #Empty column in SharePoint List
    Set-PnPPropertyBagValue -Key "SecurityGroupUsers" -Value " "
    Set-PnPPropertyBagValue -Key "MicrosoftGroupUsers" -Value " " 
    Set-PnPPropertyBagValue -Key "AddedMember" -Value " "
    Set-PnPPropertyBagValue -Key "RemovedMember" -Value " "
    Set-PnPPropertyBagValue -Key "LastSync" -Value " "
    $SecurityGroup = @{ Id = "" ; Name = "" }
    $SecurityGroupJson = $SecurityGroup | ConvertTo-Json
    Set-PnPPropertyBagValue -Key "SecurityGroupLinked" -Value $SecurityGroupJson

    # Associate values to output bindings by calling 'Push-OutputBinding'.
    $body = "ok"
    Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
        StatusCode = [HttpStatusCode]::OK
        Body = $body
    })
}

catch{
    Write-Host $Error
    $body = 'An error occured : ' + $Error 
    Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = [HttpStatusCode]::InternalServerError
    Body = $body
    })
}

