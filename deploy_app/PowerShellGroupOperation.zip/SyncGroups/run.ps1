# Input bindings are passed in via param block.
param($Timer)

# Get the current universal time in the default string format.
$currentUTCtime = (Get-Date).ToUniversalTime()

$tenantId = $env:TenantId
$siteUrl = $env:AdminSharePointSite
$appId = $env:AzureAppId
$thumbprint = $env:WEBSITE_LOAD_CERTIFICATES


$tempListSecurityMembers = ""
$global:listSecurityMembers = ""
$global:listMicrosoftMembers = ""
$global:newListSecurityMembers = @()
$global:securityGroupMembers = @()
$global:securityGroupMembersId = @()



#function to get security group members
function getSecurityGroupMembers {
    param([Parameter(Mandatory = $true)] [string] $securityGroupID)
    Write-Host "Entering get security group members"
    Write-Host $securityGroupID
    $securityGroup = Get-AzADGroupMember -GroupObjectId $securityGroupID
    #foreach members, add it to arrays if user, if group call function again
    foreach($member in $securityGroup){
        if($member.Type -eq "User"){
            $global:securityGroupMembers += $member
            $global:securityGroupMembersId += $member.Id
        }
        elseIf($member.Type -eq "Group"){
            getSecurityGroupMembers -securityGroupID $member.Id 
        }
    }
}

#function to add new security members to microsoft group
function AddMembers {
    param([Parameter(Mandatory = $true)] [string] $microsoftGroupID)
    Write-Host "Entering Function"
    #foreach member of security group, add it to group if not already in
    foreach($member in $global:securityGroupMembers){   
        Write-Host $global:securityGroupUsersId
        $isIn = $global:securityGroupUsersId -contains $member.Id
        Write-Host $isIn
        if(-Not($global:securityGroupUsersId -contains $member.Id)){
            Add-AzADGroupMember -MemberObjectId $member.Id -TargetGroupObjectId $microsoftGroupID     
        }  
        else {
            Write-Host "Already exist"
        }  
        $global:newListSecurityMembers += @{Id = $member.Id ; Name = $member.DisplayName}     
    }
}

#function to remove members that are no more in security group and not in microsoft group
function RemoveMembers{
    param([Parameter(Mandatory = $true)] [string] $microsoftGroupID)
    foreach($member in $global:securityGroupUsersId){
        if( (-Not($global:securityGroupMembersId -contains $member)) -and (-Not($global:microsoftGroupUsersId -contains $member)) ){
            Remove-AzADGroupMember -GroupObjectId $microsoftGroupID -MemberObjectId $member
        }
        else{
            Write-Host "Users is in security Group"
        }
    }    
}



$spconnect = Connect-PnPOnline -ClientId $appId -Thumbprint $thumbprint -Tenant $tenantId -Url $siteUrl
$azconnect = Connect-AzAccount -CertificateThumbprint $thumbprint -ApplicationId $appId -Tenant $tenantId -ServicePrincipal


$sites= Get-PnPTenantSite
foreach($site in $sites){
    if($site.Template -eq "GROUP#0"){
        Connect-PnPOnline -ClientId $appId -Thumbprint $thumbprint -Tenant $tenantId -Url $site.Url
        $isEnabled = Get-PnPPropertyBag -Key "syncGroupAppEnabled"
        if($isEnabled){
            $currentDate = Get-Date -Format 'dd/MM/yyyy'
            $currentHours = Get-Date -Format 'HH'
            $currentMinutes= Get-Date -Format 'mm'
            $syncDate =  $currentDate + " at " +  $currentHours+"h"+$currentMinutes
            Write-Host "Sync App is enabled"
            #Get item from SharePoint, and field SecurityGroupUsers ; MicrosoftGroupUsers
            $securityGroupJson = Get-PnPPropertyBag -Key "SecurityGroupLinked"
            $securityGroup = $securityGroupJson | ConvertFrom-Json
            $securityGroupId = $securityGroup.Id
            $microsoftGroupJson = Get-PnPPropertyBag -Key "MicrosoftGroup"
            $microsoftGroup = $microsoftGroupJson | ConvertFrom-Json
            $microsoftGroupId = $microsoftGroup.Id
            $securityGroupUsersJson = Get-PnPPropertyBag -Key "SecurityGroupUsers"
            $securityGroupUsers = $securityGroupUsersJson | ConvertFrom-Json
            Write-Host $securityGroupUsers
            $global:securityGroupUsersId = @()
            foreach($member in $securityGroupUsers){
                $global:securityGroupUsersId += $member.Id
            }
            Write-Host $global:securityGroupUsersId
            $microsoftGroupUsersJson = Get-PnPPropertyBag -Key "MicrosoftGroupUsers"
            $microsoftGroupUsers = $microsoftGroupUsersJson | ConvertFrom-Json
            $global:microsoftGroupUsersId = @()
            foreach($member in $microsoftGroupUsers){
                $global:microsoftGroupUsersId += $member.Id
            }
            #Call function
            getSecurityGroupMembers -securityGroupID $securityGroupId 
            #call function
            AddMembers -microsoftGroupID $microsoftGroupId       
            #call function
            RemoveMembers -microsoftGroupID $microsoftGroupId
            #Set SharePoint item to refresh SecurityGroupUsers field
            $newListSecurityMembersJson = $global:newListSecurityMembers |ConvertTo-Json
            Set-PnPPropertyBagValue -Key "SecurityGroupUsers" -Value $newListSecurityMembersJson
             Set-PnPPropertyBagValue -Key "LastSync" -Value $syncDate
            Disconnect-PnPOnline
        }
    }
}

# Write an information log with the current time.
Write-Host "PowerShell timer trigger function ran! TIME: $currentUTCtime"
